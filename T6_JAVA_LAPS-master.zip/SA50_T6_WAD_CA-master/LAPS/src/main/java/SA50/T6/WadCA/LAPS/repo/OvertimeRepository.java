package SA50.T6.WadCA.LAPS.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import SA50.T6.WadCA.LAPS.model.Overtime;

public interface OvertimeRepository extends JpaRepository<Overtime, Integer>{

}
