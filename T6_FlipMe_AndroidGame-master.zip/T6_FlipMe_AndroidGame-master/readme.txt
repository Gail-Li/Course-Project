3rd party libraries: To be able to use gif images in the app - https://github.com/koral--/android-gif-drawable
Source Code: Nil 

Contribution:
Jane- Web scrapping, Image fetch, selection, Image matching, Onboarding tutorial(codes), counting matches
Lydia- Video tutorial(codes)
May- Images selection (toggle/select/unselect), app testing
Sherren- Game countdown timer, Leader board, score tabulation
Wayne- Welcome animation, All Icons, graphics and video, Swipe up to Main page, Game graphics and design 
Xin Ying- Game music
